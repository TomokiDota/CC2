#ifndef FORMPRODUCTONUEVO_H
#define FORMPRODUCTONUEVO_H

#include <QWidget>

namespace Ui {
class FormProductoNuevo;
}

class FormProductoNuevo : public QWidget
{
    Q_OBJECT

public:
    explicit FormProductoNuevo(QWidget *parent = 0);
    ~FormProductoNuevo();

private slots:
    void on_BGuardar_clicked();

private:
    Ui::FormProductoNuevo *ui;
};

#endif // FORMPRODUCTONUEVO_H
