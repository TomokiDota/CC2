#ifndef FORMVENTADETALLE_H
#define FORMVENTADETALLE_H

#include <QWidget>

namespace Ui {
class FormVentaDetalle;
}

class FormVentaDetalle : public QWidget
{
    Q_OBJECT

public:
    explicit FormVentaDetalle(QWidget *parent = 0);
    ~FormVentaDetalle();

private slots:
    void on_BBuscar_clicked();

    void on_BBuscarProducto_clicked();

    void on_BAgregar_clicked();

    void on_BEliminar_clicked();

private:
    Ui::FormVentaDetalle *ui;
};

#endif // FORMVENTADETALLE_H
