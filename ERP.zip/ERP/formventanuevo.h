#ifndef FORMVENTANUEVO_H
#define FORMVENTANUEVO_H

#include <QWidget>

namespace Ui {
class FormVentaNuevo;
}

class FormVentaNuevo : public QWidget
{
    Q_OBJECT

public:
    explicit FormVentaNuevo(QWidget *parent = 0);
    ~FormVentaNuevo();

private slots:
    void on_BGuardar_clicked();

    void on_BBuscar_clicked();

private:
    Ui::FormVentaNuevo *ui;
};

#endif // FORMVENTANUEVO_H
