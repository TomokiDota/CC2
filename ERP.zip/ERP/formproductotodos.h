#ifndef FORMPRODUCTOTODOS_H
#define FORMPRODUCTOTODOS_H

#include <QWidget>

namespace Ui {
class FormProductoTodos;
}

class FormProductoTodos : public QWidget
{
    Q_OBJECT

public:
    explicit FormProductoTodos(QWidget *parent = 0);
    ~FormProductoTodos();

private slots:
    void on_BModificar_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::FormProductoTodos *ui;
};

#endif // FORMPRODUCTOTODOS_H
