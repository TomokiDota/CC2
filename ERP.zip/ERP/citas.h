#ifndef CITAS_H
#define CITAS_H
#include <QString>
using namespace std;

class Cita
{
    private:
        int idcitas;
        QString consultorio;
        int DNIClie;

    public:
        Cita(){

        }
        Cita(int idcitas, QString consultorio, int DNIClie){
            this->idcitas = idcitas;
            this->consultorio =consultorio;
            this->DNIClie=DNIClie;
        }
        virtual ~Cita(){

        }

        int Getidcitas() {
            return idcitas;
        }
        void Setidcitas(int val) {
            idcitas = val;
        }
        QString Getconsultorio() {
            return consultorio;
        }
        void Setconsultorio( QString val) {
            consultorio = val;
        }
        int GetDNIClie() {
            return DNIClie;
        }
        void SetDNIClie( int val) {
            DNIClie = val;
        }

        QString insertQuery(){
            return "INSERT INTO citas (consultorio, cliente) VALUES ('"+consultorio+"',"+QString::number(DNIClie)+");";
        }
        QString updateQuery(){
            return "UPDATE citas SET consultorio = '"+consultorio+"', cliente = '"+QString::number(DNIClie)+"' WHERE idcitas= "+QString::number(idcitas)+";";
        }

};
#endif // CITAS_H
