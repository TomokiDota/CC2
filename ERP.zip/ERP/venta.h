#ifndef VENTA_H
#define VENTA_H
#include <QString>
using namespace std;

class Venta
{
    private:
        int CodiVent;
        QString FechVent;
        int DNIClie;

    public:
        Venta(){

        }
        Venta(int CodiVent, QString FechVent, int DNIClie){
            this->CodiVent = CodiVent;
            this->FechVent =FechVent;
            this->DNIClie=DNIClie;
        }
        virtual ~Venta(){

        }

        int GetCodiVent() {
            return CodiVent;
        }
        void SetCodiVent(int val) {
            CodiVent = val;
        }
        QString GetFechVent() {
            return FechVent;
        }
        void SetFechVent( QString val) {
            FechVent = val;
        }
        int GetDNIClie() {
            return DNIClie;
        }
        void SetDNIClie( int val) {
            DNIClie = val;
        }

        QString insertQuery(){
            return "INSERT INTO ventprod (FechVent, DNIClie) VALUES ('"+FechVent+"',"+QString::number(DNIClie)+");";
        }
        QString updateQuery(){
            return "UPDATE ventprod SET FechVent = '"+FechVent+"', DNIClie = '"+QString::number(DNIClie)+"' WHERE CodiVent= "+QString::number(CodiVent)+";";
        }

};
#endif // VENTA_H
