#include "formcitasnuevo.h"
#include "ui_formcitasnuevo.h"
#include "FacadeCitas.h"

FormCitasNuevo::FormCitasNuevo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormCitasNuevo)
{
    ui->setupUi(this);
}

FormCitasNuevo::~FormCitasNuevo()
{
    delete ui;
}

void FormCitasNuevo::on_BNuevo_clicked()
{
    QString DNI=ui->tdni->toPlainText();
    QString cons=ui->tconsu->toPlainText();
    Cita * cita= new Cita(0,cons,DNI.toInt());
    FacadeCitas::AgregarCitas(cita->insertQuery());
    this->close();
}

void FormCitasNuevo::on_BBuscar_clicked()
{
     QString DNI=ui->tdni->toPlainText();
     QList<Cliente*> list = FacadeCitas::BuscarCliente(DNI.toInt());
     if(list.size()==1){
         Cliente * pro = list[0];
         ui->tnom->setText(pro->GetNombre());
     }else{
         ui->tdni->setText("");
     }

}
