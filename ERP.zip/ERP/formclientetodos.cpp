#include "formclientetodos.h"
#include "ui_formclientetodos.h"

#include "facadeadmin.h"
#include "formclientenuevo.h"
#include "formclientemodificar.h"

#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>

FormClienteTodos::FormClienteTodos(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormClienteTodos)
{
    ui->setupUi(this);
    QStandardItemModel *model = new QStandardItemModel(2,3,this); //2 Rows and 3 Columns
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("DNI")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Nombre")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("Telefono")));
    model->setHorizontalHeaderItem(3, new QStandardItem(QString("Correo")));

    QList<Cliente*> lista=FacadeAdmin::BuscarTodosCliente();
    //QStandardItem *firstRow = new QStandardItem(QString(lista[0]));
    //model->setItem(0,0,firstRow);

    for (int i = 0; i < lista.size(); ++i) {
        Cliente* cli =lista.at(i);
        //cout << "Nombre " << cli->GetNombre() << endl;
        qDebug()<<lista.size();
        model->setItem(i,0,new QStandardItem(QString::number(cli->Getdni())));
        model->setItem(i,1,new QStandardItem(QString(cli->GetNombre())));
        model->setItem(i,2,new QStandardItem(QString(cli->GetTelefono())));
        model->setItem(i,3,new QStandardItem(QString(cli->GetCorreo())));

    }
    ui->TClienteTodo->setModel(model);
}

FormClienteTodos::~FormClienteTodos()
{
    delete ui;
}

void FormClienteTodos::on_BNuevo_clicked()
{
    FormClienteNuevo * FAdminClienteNuevo = new FormClienteNuevo();
    FAdminClienteNuevo->show();
}

void FormClienteTodos::on_BModificar_clicked()
{
    FormClienteModificar * FAdminClienteModificar = new FormClienteModificar();
    FAdminClienteModificar->show();
}
