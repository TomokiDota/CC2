#ifndef CLIENTE_H
#define CLIENTE_H

#include <QString>
using namespace std;

class Cliente
{
    private:
        int dni;
        QString Nombre;
        QString Telefono;
        QString Correo;

    public:
        Cliente(){

        }
        Cliente(int dni, QString Nombre, QString Telefono, QString Correo){
            this->dni = dni;
            this->Nombre =Nombre;
            this->Telefono=Telefono;
            this->Correo=Correo;
        }
        virtual ~Cliente(){

        }

        int Getdni() {
            return dni;
        }
        void Setdni(int val) {
            dni = val;
        }
        QString GetNombre() {
            return Nombre;
        }
        void SetNombre( QString val) {
            Nombre = val;
        }
        QString GetTelefono() {
            return Telefono;
        }
        void SetTelefono( QString val) {
            Telefono = val;
        }

        QString GetCorreo() {
            return Correo;
        }
        void SetCorreo( QString val) {
            Correo = val;
        }

        QString insertQuery(){
            return "INSERT INTO cliente (DNIClie, NombClie, TeleClie, CorrClie) VALUES ("+QString::number(dni)+",'"+Nombre+"','"+Telefono+"','"+Correo+"');";
        }
        QString updateQuery(){
            return "UPDATE cliente SET NombClie = '"+Nombre+"', TeleClie = '"+Telefono+"', CorrClie = '"+Correo+"' WHERE DNIClie= "+QString::number(dni)+";";
        }

};

#endif // CLIENTE_H
