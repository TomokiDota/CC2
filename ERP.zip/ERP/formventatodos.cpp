#include "formventatodos.h"
#include "ui_formventatodos.h"

#include "facadeadmin.h"
#include "formventanuevo.h"
#include "formventadetalle.h"

#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>

FormVentaTodos::FormVentaTodos(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormVentaTodos)
{
    ui->setupUi(this);
    QStandardItemModel *model = new QStandardItemModel(2,3,this); //2 Rows and 3 Columns
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Codigo")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Fecha")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("DNI Cliente")));

    QList<Venta*> lista=FacadeAdmin::BuscarTodasVenta();

    for (int i = 0; i < lista.size(); ++i) {
        Venta* vent =lista.at(i);
        qDebug()<<lista.size();
        model->setItem(i,0,new QStandardItem(QString::number(vent->GetCodiVent())));
        model->setItem(i,1,new QStandardItem(QString(vent->GetFechVent())));
        model->setItem(i,2,new QStandardItem(QString::number(vent->GetDNIClie())));

    }
    ui->TVentaTodo->setModel(model);
}


FormVentaTodos::~FormVentaTodos()
{
    delete ui;
}

void FormVentaTodos::on_BNuevo_clicked()
{
    FormVentaNuevo * formVentaNuevo = new FormVentaNuevo();
    formVentaNuevo->show();
}

void FormVentaTodos::on_BVerDetalle_clicked()
{
    FormVentaDetalle * formVentaDetalle = new FormVentaDetalle();
    formVentaDetalle->show();
}
