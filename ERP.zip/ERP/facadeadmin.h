#ifndef FACADEADMIN_H
#define FACADEADMIN_H

#include "AdminCliente.h"
#include "AdminProducto.h"
#include "adminventa.h"

class FacadeAdmin{
    public:
    static void CrearCliente(Cliente * cliente){
        AdminCliente::Agregar(cliente->insertQuery());
    }
    static QList<Cliente*> BuscarCliente(int clave){
        QList<Cliente*> lista=AdminCliente::BuscarPorClave(clave);
        return lista;
    }
    static QList<Cliente*> BuscarTodosCliente(){
        QList<Cliente*> lista=AdminCliente::BuscarTodos();
        return lista;
    }
    static void ModificarCliente(Cliente * cliente){
        AdminCliente::Modificar(cliente->updateQuery());
    }
    static void EliminarCliente(int clave){
        AdminCliente::Eliminar(clave);
    }

    static void CrearProducto(Producto * producto){
        AdminProducto::Agregar(producto->insertQuery());
    }
    static QList<Producto*> BuscarTodosProducto(){
        QList<Producto*> lista=AdminProducto::BuscarTodos();
        return lista;
    }
    static QList<Producto*> BuscarProducto(int clave){
        QList<Producto*> lista=AdminProducto::BuscarPorClave(clave);
        return lista;
    }

    static void CrearVenta(Venta * venta){
        AdminVenta::Agregar(venta->insertQuery());
    }
    static void ModificarProducto(Producto * producto){
        AdminProducto::Modificar(producto->updateQuery());
    }
    static void EliminarProducto(int clave){
        AdminProducto::Eliminar(clave);
    }

    static QList<Venta*>  BuscarVenta(int clave){
        QList<Venta*> lista=AdminVenta::BuscarPorClave(clave);
        return lista;
    }
    static QList<Venta*>  BuscarTodasVenta(){
        QList<Venta*> lista=AdminVenta::BuscarTodos();
        return lista;
    }

    static void ModificarVenta(Venta * venta){
        AdminVenta::Modificar(venta->updateQuery());
    }

    static QList<VentaDetalle*> ObtenerDetalleVenta(Venta * venta){
        QList<VentaDetalle*> lista=AdminVenta::ObtenerDetalle(venta->GetCodiVent());
        return lista;
    }

    static void AgregarVentaDetalle(int idventa,int idprod,int stock){
        AdminVenta::AgregarProducto(idventa,idprod,stock);
    }

    static void EliminarVentaDetalle(int idventa,int idprod){
        AdminVenta::DeleteProducto(idventa,idprod);
    }
};

#endif // FACADEADMIN_H
