#include "formproductomodificar.h"
#include "ui_formproductomodificar.h"
#include "facadeadmin.h"
#include "producto.h"
#include <QString>

FormProductoModificar::FormProductoModificar(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormProductoModificar)
{
    ui->setupUi(this);
}

FormProductoModificar::~FormProductoModificar()
{
    delete ui;
}

void FormProductoModificar::on_BGuardar_clicked()
{
    QString codigo=ui->TCodigo->toPlainText();
    QString Nombre=ui->TNombre->toPlainText();
    QString Precio=ui->TPrecio->toPlainText();
    QString Stock=ui->TStock->toPlainText();

    Producto * pro = new Producto(0,Nombre,Stock.toInt(),Precio.toDouble());
    pro->SetCodigo(codigo.toInt());
    FacadeAdmin::ModificarProducto(pro);
    this->close();
}

void FormProductoModificar::on_BBuscar_clicked()
{
    QString codigo=ui->TCodigo->toPlainText();
    QList<Producto*> lprod = FacadeAdmin::BuscarProducto(codigo.toInt());
    if(lprod.size()==1){
        Producto * pro = lprod[0];
        ui->TNombre->setText(pro->GetNombre());
        ui->TPrecio->setText(QString::number(pro->GetPrecio()));
        ui->TStock->setText(QString::number(pro->GetStock()));
    }else{
        ui->TCodigo->setText("");
    }
}
