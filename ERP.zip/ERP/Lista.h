#include<iostream>
#include<cstdlib>
#include"Nodo.h"
using namespace std;

#if !defined Lista_h
#define Lista_h

template<class t_dato>
class Lista
{
    private:
        Nodo<t_dato> *lista;
        int size;

	public:
        Lista() {
            lista = NULL;
            size = 0;
        }

        Lista(t_dato dato);

        void anadir(int nceldas);

        int esVacia() {
            return (lista == NULL);
        }

        void insertar(t_dato dato);

        t_dato recuperar(int index);

        void poner(t_dato dato, int index);

        void eliminar(int index);

        long length() {
            return size;
        }

        ~Lista();
};

#endif
// CPP FILE
