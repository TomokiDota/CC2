#ifndef FORMCITASTODOS_H
#define FORMCITASTODOS_H

#include <QWidget>

namespace Ui {
class FormCitasTodos;
}

class FormCitasTodos : public QWidget
{
    Q_OBJECT

public:
    explicit FormCitasTodos(QWidget *parent = 0);
    ~FormCitasTodos();

private slots:
    void on_BNuevo_clicked();

private:
    Ui::FormCitasTodos *ui;
};

#endif // FORMCITASTODOS_H
