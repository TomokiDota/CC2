#ifndef ADMINCLIENTE_H
#define ADMINCLIENTE_H

#include "Cliente.h"
#include "admindata.h"
#include "AdminBase.h"
#include <QDebug>
#include <QString>
#include <QList>


class AdminCliente : public AdminBase
{
    public:
        static void Agregar(QString cliente){
            AdminData data = AdminData::getInstance();
            data.execQuery(cliente);
        }
        static QList<Cliente*> BuscarPorClave(int clave){
           AdminData data = AdminData::getInstance();
           QSqlQuery query=data.execQuery("SELECT * FROM cliente WHERE DNIClie = "+QString::number(clave)+";");
           QList<Cliente*> listaCliente;
           while (query.next()) {
               listaCliente.append(new Cliente(query.value(0).toInt(),
                                                  query.value(1).toString(),
                                                  query.value(2).toString(),
                                                  query.value(3).toString()
                                                  )
                                      );
           }
           return listaCliente;
        }
        static QList<Cliente*> BuscarTodos(){
            AdminData data = AdminData::getInstance();
            QSqlQuery query=data.execQuery("SELECT * FROM cliente ;");
            QList<Cliente*> listaCliente;
            while (query.next()) {
                listaCliente.append(new Cliente(query.value(0).toInt(),
                                                   query.value(1).toString(),
                                                   query.value(2).toString(),
                                                   query.value(3).toString()
                                                   )
                                       );
            }
            return listaCliente;
        }
        static void Modificar(QString cliente){
            AdminData data = AdminData::getInstance();
            data.execQuery(cliente);
        }
        static void Eliminar(int clave){
            AdminData data = AdminData::getInstance();
            data.execQuery("DELETE FROM  cliente WHERE DNIClie = "+QString::number(clave)+";");
        }

};

#endif // ADMINCLIENTE_H
