#include "Lista.h"

template<class t_dato>
Lista<t_dato>::Lista(t_dato dato)
{
    lista = new Nodo<t_dato>(dato);
    size++;
}

template<class t_dato>
void Lista<t_dato>::anadir(int nceldas)
{
    Nodo<t_dato> *temp;
    int i = 0;

    if(esVacia())
    {
        Nodo<t_dato> *nodo = new Nodo<t_dato>();
        lista = nodo;
        i++;
        size++;
    }
    for(; i<nceldas; i++)
    {
        Nodo<t_dato> *nodo = new Nodo<t_dato>();
        temp = lista;
        while(temp->siguiente())
            temp = temp->siguiente();
        temp->insertar(nodo);
        size++;
    }
}

template<class t_dato>
void Lista<t_dato>::insertar(t_dato dato)
{
    Nodo<t_dato> *nodo = new Nodo<t_dato>(dato);
    Nodo<t_dato> *temp = lista;

    if(esVacia())
    {
        lista = nodo;
    }
    else
    {
        while(temp->siguiente())
            temp = temp->siguiente();
        temp->insertar(nodo);
    }
    size++;
}

template<class t_dato>
t_dato Lista<t_dato>::recuperar(int index)
{
    int i=0;
    Nodo<t_dato> *nodo = lista;

    if(!esVacia())
    {
        if(size < index)
        {
            exit(1);
        }
        while((i<index) && (nodo))
        {
            nodo = nodo->siguiente();
            i++;
        }
        return (nodo->elemento());

    }
    exit(1);
}

template<class t_dato>
void Lista<t_dato>::eliminar(int index)
{
    int i=0;
    Nodo<t_dato> *nodo = lista,*ante=lista;

    if(!esVacia())
    {
        if(index == 0)
            lista = lista->siguiente();
        while((i<index) && (nodo))
        {
            ante = nodo;
            nodo = nodo->siguiente();
        }
        if(nodo)
            ante->insertar(nodo->siguiente());
        delete(nodo);
        size--;
    }
}

template<class t_dato>
Lista<t_dato>::~Lista()
{
    while(!esVacia())
        eliminar(0);
    size = 0;
}
