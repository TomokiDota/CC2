#ifndef FORMVENTATODOS_H
#define FORMVENTATODOS_H

#include <QWidget>

namespace Ui {
class FormVentaTodos;
}

class FormVentaTodos : public QWidget
{
    Q_OBJECT

public:
    explicit FormVentaTodos(QWidget *parent = 0);
    ~FormVentaTodos();

private slots:
    void on_BNuevo_clicked();

    void on_BVerDetalle_clicked();

private:
    Ui::FormVentaTodos *ui;
};

#endif // FORMVENTATODOS_H
