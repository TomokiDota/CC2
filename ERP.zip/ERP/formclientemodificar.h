#ifndef FORMCLIENTEMODIFICAR_H
#define FORMCLIENTEMODIFICAR_H

#include <QWidget>

namespace Ui {
class FormClienteModificar;
}

class FormClienteModificar : public QWidget
{
    Q_OBJECT

public:
    explicit FormClienteModificar(QWidget *parent = 0);
    ~FormClienteModificar();

private slots:
    void on_BGuardar_clicked();

    void on_BBuscar_clicked();

private:
    Ui::FormClienteModificar *ui;
};

#endif // FORMCLIENTEMODIFICAR_H
