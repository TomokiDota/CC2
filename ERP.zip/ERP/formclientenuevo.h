#ifndef FORMCLIENTENUEVO_H
#define FORMCLIENTENUEVO_H

#include <QWidget>

namespace Ui {
class FormClienteNuevo;
}

class FormClienteNuevo : public QWidget
{
    Q_OBJECT

public:
    explicit FormClienteNuevo(QWidget *parent = 0);
    ~FormClienteNuevo();

private slots:
    void on_BGuardar_clicked();

private:
    Ui::FormClienteNuevo *ui;
};

#endif // FORMCLIENTENUEVO_H
