#include "formventanuevo.h"
#include "ui_formventanuevo.h"
#include "facadeadmin.h"
#include "venta.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>


FormVentaNuevo::FormVentaNuevo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormVentaNuevo)
{
    ui->setupUi(this);
}

FormVentaNuevo::~FormVentaNuevo()
{
    delete ui;
}

void FormVentaNuevo::on_BGuardar_clicked()
{
    QString DNI=ui->tdni->toPlainText();
    QString Fecha=ui->tfecha->toPlainText();
    Venta * VentitaP=new Venta(0,Fecha,DNI.toInt());
    FacadeAdmin::CrearVenta(VentitaP);
    this->close();
}
void FormVentaNuevo::on_BBuscar_clicked()
{
    QString dni=ui->tdni->toPlainText();
    QList<Cliente*> Lcli = FacadeAdmin::BuscarCliente(dni.toInt());
    if(Lcli.size()==1){
        Cliente * cli = Lcli[0];
        ui->TNombre->setText(cli->GetNombre());
    }else{
        ui->tdni->setText("");
    }
}
