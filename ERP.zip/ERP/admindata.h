#ifndef ADMINDATA_H
#define ADMINDATA_H

#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QString>
#include <QMessageBox>
#include <QSqlError>

using namespace std;

class AdminData
{
    private:
        QSqlDatabase data;
        AdminData();
    public:
        // singleton
        static AdminData& getInstance();
        QSqlQuery execQuery(QString);


};

#endif // ADMINDATA_H
