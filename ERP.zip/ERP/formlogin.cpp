#include "formlogin.h"
#include "ui_formlogin.h"
#include "formadmin.h"
FormLogin::FormLogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormLogin)
{
    ui->setupUi(this);
}

FormLogin::~FormLogin()
{
    delete ui;
}

void FormLogin::on_loggin_b_clicked()
{
    QString username=ui->username_txt->toPlainText();
    QString clave=ui->clave_txt->text();
    if(username=="admin" && clave=="1234")
    {
       FormAdmin * open=new FormAdmin();
       open->show();
       this->close();
    }
    else if(username=="Selene" && clave=="2018")
    {
       FormAdmin * open=new FormAdmin();
       open->show();
       this->close();
    }
    if(username=="Luz" && clave=="qtrct")
    {
       FormAdmin * open=new FormAdmin();
       open->show();
       this->close();
    }

}
