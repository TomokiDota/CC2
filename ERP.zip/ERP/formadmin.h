#ifndef FORMADMIN_H
#define FORMADMIN_H

#include <QWidget>

namespace Ui {
class FormAdmin;
}

class FormAdmin : public QWidget
{
    Q_OBJECT

public:
    explicit FormAdmin(QWidget *parent = 0);
    ~FormAdmin();

private slots:
    void on_BCliente_clicked();

    void on_BProducto_clicked();

    void on_BVenta_clicked();

private:
    Ui::FormAdmin *ui;
};

#endif // FORMADMIN_H
