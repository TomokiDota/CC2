#ifndef FORMCLIENTETODOS_H
#define FORMCLIENTETODOS_H

#include <QWidget>
#include <QTableView>

namespace Ui {
class FormClienteTodos;
}

class FormClienteTodos : public QWidget
{
    Q_OBJECT

public:
    explicit FormClienteTodos(QWidget *parent = 0);
    ~FormClienteTodos();

private slots:

    void on_BNuevo_clicked();

    void on_BModificar_clicked();

private:
    Ui::FormClienteTodos *ui;
};

#endif // FORMCLIENTETODOS_H
