#ifndef ADMINPRODUCTO_H
#define ADMINPRODUCTO_H

#include "producto.h"
#include "admindata.h"
#include "AdminBase.h"
#include <QDebug>
#include <QString>
#include <QList>


class AdminProducto: public AdminBase
{
    public:
        static void Agregar(QString producto){
            //producto  =  sentencia insert
            AdminData data = AdminData::getInstance();
            data.execQuery(producto);
        }
        static QList<Producto*> BuscarPorClave(int clave){
           AdminData data = AdminData::getInstance();
           QSqlQuery query=data.execQuery("SELECT * FROM producto WHERE CodiProd = "+QString::number(clave)+";");
           QList<Producto*> lista;
           while (query.next()) {
               lista.append(new Producto(query.value(0).toInt(),
                                                  query.value(1).toString(),
                                                  query.value(2).toInt(),
                                                  query.value(3).toDouble()
                                                  )
                                      );
           }
           return lista;
        }
        static QList<Producto*> BuscarTodos(){
            AdminData data = AdminData::getInstance();
            QSqlQuery query=data.execQuery("SELECT * FROM producto ;");
            QList<Producto*> lista;
            while (query.next()) {
                lista.append(new Producto(query.value(0).toInt(),
                                                   query.value(1).toString(),
                                                   query.value(2).toInt(),
                                                   query.value(3).toDouble()
                                                   )
                                       );
            }
            return lista;
        }
        static void Modificar(QString producto){
            AdminData data = AdminData::getInstance();
            data.execQuery(producto);
        }
        static void Eliminar(int clave){
            AdminData data = AdminData::getInstance();
            data.execQuery("DELETE FROM  producto WHERE CodiProd = "+QString::number(clave)+";");
        }

};

#endif // ADMINPRODUCTO_H
