#ifndef PRODUCTO_H
#define PRODUCTO_H
#include <QString>
using namespace std;

class Producto
{
    private:
        int Codigo;
        QString Nombre;
        int Stock;
        double Precio;

    public:
        Producto(){

        }
        Producto(int Codigo, QString Nombre, int Stock, double Precio){
            this->Codigo = Codigo;
            this->Nombre =Nombre;
            this->Stock=Stock;
            this->Precio=Precio;
        }

        virtual ~Producto(){

        }

        int GetCodigo() {
            return Codigo;
        }
        void SetCodigo(int val) {
            Codigo = val;
        }
        QString GetNombre() {
            return Nombre;
        }
        void SetNombre( QString val) {
            Nombre = val;
        }
        int GetStock() {
            return Stock;
        }
        void SetStock( int val) {
            Stock = val;
        }

        double GetPrecio() {
            return Precio;
        }
        void SetPrecio( double val) {
            Precio = val;
        }

        QString insertQuery(){
            return "INSERT INTO Producto ( NombProd, StckProd, PrecProd) VALUES ('"+Nombre+"','"+QString::number(Stock)+"','"+QString::number(Precio)+"');";
        }
        QString updateQuery(){
            return "UPDATE Producto SET NombProd = '"+Nombre+"', StckProd = '"+QString::number(Stock)+"', PrecProd = '"+QString::number(Precio)+"' WHERE CodiProd= "+QString::number(Codigo)+";";
        }

};

#endif // PRODUCTO_H
