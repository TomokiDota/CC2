#include "formclientenuevo.h"
#include "ui_formclientenuevo.h"

#include <QString>
#include "Cliente.h"
#include "facadeadmin.h"

FormClienteNuevo::FormClienteNuevo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormClienteNuevo)
{
    ui->setupUi(this);
}

FormClienteNuevo::~FormClienteNuevo()
{
    delete ui;
}

void FormClienteNuevo::on_BGuardar_clicked()
{
    QString DNI=ui->TDni->toPlainText();
    QString Nombre=ui->TXNombre->toPlainText();
    QString Telefono=ui->TXTelefono->toPlainText();
    QString correo=ui->TXCorreo->toPlainText();

    Cliente * cli = new Cliente(DNI.toInt(),Nombre,Telefono,correo);
    FacadeAdmin::CrearCliente(cli);
    this->close();
}
