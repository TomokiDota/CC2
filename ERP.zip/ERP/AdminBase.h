#ifndef ADMINBASE_H
#define ADMINBASE_H

#include <string>
using namespace std;

class AdminBase
{
public:
    static void Agregar(string);
    static void BuscarPorClave(int);
    static void BuscarTodos();
    static void Modificar(string);
    static void Eliminar(int);
};

#endif // ADMINBASE_H
