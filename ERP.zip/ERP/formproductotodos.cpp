#include "formproductotodos.h"
#include "ui_formproductotodos.h"

#include "facadeadmin.h"
#include "formproductonuevo.h"
#include "formproductomodificar.h"

#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>

FormProductoTodos::FormProductoTodos(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormProductoTodos)
{
    ui->setupUi(this);
    QStandardItemModel *model = new QStandardItemModel(2,3,this); //2 Rows and 3 Columns
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("Codigo")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Nombre")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("Stock")));
    model->setHorizontalHeaderItem(3, new QStandardItem(QString("Precio")));

    QList<Producto*> lista=FacadeAdmin::BuscarTodosProducto();
    //QStandardItem *firstRow = new QStandardItem(QString(lista[0]));
    //model->setItem(0,0,firstRow);

    for (int i = 0; i < lista.size(); ++i) {
        Producto* prod =lista.at(i);
        //cout << "Nombre " << cli->GetNombre() << endl;
        qDebug()<<lista.size();
        model->setItem(i,0,new QStandardItem(QString::number(prod->GetCodigo())));
        model->setItem(i,1,new QStandardItem(QString(prod->GetNombre())));
        model->setItem(i,2,new QStandardItem(QString::number(prod->GetStock())));
        model->setItem(i,3,new QStandardItem(QString::number(prod->GetPrecio())));

    }
    ui->TProductoTodo->setModel(model);
}

FormProductoTodos::~FormProductoTodos()
{
    delete ui;
}

void FormProductoTodos::on_BModificar_clicked()
{
    FormProductoModificar * formProductoModificar = new FormProductoModificar();
    formProductoModificar->show();
}

void FormProductoTodos::on_pushButton_2_clicked()
{
    FormProductoNuevo * formProductoNuevo = new FormProductoNuevo();
    formProductoNuevo->show();
}
