#ifndef ADMINCITAS_H
#define ADMINCITAS_H

#include "Cliente.h"
#include "citas.h"
#include "admindata.h"
#include "AdminBase.h"
#include <QDebug>
#include <QString>
#include <QList>


class AdminCitas : public AdminBase
{
    public:
        static void Agregar(QString scita){
            AdminData data = AdminData::getInstance();
            data.execQuery(scita);
        }

        static QList<Cita*> BuscarTodos(){
            AdminData data = AdminData::getInstance();
            QSqlQuery query=data.execQuery("SELECT * FROM citas ;");
            QList<Cita*> lista;
            while (query.next()) {
                lista.append(new Cita(query.value(0).toInt(),
                                   query.value(1).toString(),
                                   query.value(2).toInt()
                                   )
                            );
            }
            return lista;
        }

};
#endif // ADMINCITAS_H
