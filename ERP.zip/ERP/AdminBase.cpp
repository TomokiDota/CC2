#include "AdminBase.h"

AdminBase::AdminBase()
{

}
