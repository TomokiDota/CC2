#ifndef FORMPRODUCTOMODIFICAR_H
#define FORMPRODUCTOMODIFICAR_H

#include <QWidget>

namespace Ui {
class FormProductoModificar;
}

class FormProductoModificar : public QWidget
{
    Q_OBJECT

public:
    explicit FormProductoModificar(QWidget *parent = 0);
    ~FormProductoModificar();

private slots:
    void on_BGuardar_clicked();

    void on_BBuscar_clicked();

private:
    Ui::FormProductoModificar *ui;
};

#endif // FORMPRODUCTOMODIFICAR_H
