#include<iostream>
#include<cstdlib>

using namespace std;



#if !defined Nodo_h
#define Nodo_h

//***********************************************************************
//***********************CLASE NODO**************************************
//***********************************************************************

template<class t_dato>

class Nodo
{
	t_dato dato;
	Nodo *sig;

	public:
	Nodo() {
	    sig = NULL;
    }
	Nodo(t_dato dato);

	t_dato elemento() {
	    return dato;
    }

	Nodo *siguiente() {
	    return sig;
    }
	void setElemento(t_dato dato) {
	    this->dato = dato;
    }
	void insertar(Nodo *elemento) {
	    sig = elemento;
    }
};

 // CPP FILE

#endif
