#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include "admindata.h"
#include <QWidget>
#include <QSqlDatabase>
#include <QSqlTableModel>

namespace Ui {
class MainWidget;
}

//class QSqlTableModel;

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

private slots:
    void on_Farmacia_clicked();

    void on_Administrador_clicked();

private:
    Ui::MainWidget *ui;

  // QSqlTableModel *mModel;
  //  QSqlDatabase mDatabase;
};

#endif // MAINWIDGET_H
