#include "formventadetalle.h"
#include "ui_formventadetalle.h"

#include "facadeadmin.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>

FormVentaDetalle::FormVentaDetalle(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormVentaDetalle)
{
    ui->setupUi(this);
}

FormVentaDetalle::~FormVentaDetalle()
{
    delete ui;
}

void FormVentaDetalle::on_BBuscar_clicked()
{
    QString codigo=ui->tcodigo->toPlainText();
    QList<Venta*> Lven = FacadeAdmin::BuscarVenta(codigo.toInt());
    Venta * ven;
    if(Lven.size()==1){
        ven = Lven[0];
        ui->tfecha->setText(ven->GetFechVent());
        ui->tdni->setText(QString::number(ven->GetDNIClie()));
        QList <Cliente*> cli= FacadeAdmin::BuscarCliente(ven->GetDNIClie());
        if(cli.size()==1){
            Cliente * cliente = cli[0];
            ui->tnombre->setText(cliente->GetNombre());
        }

        QStandardItemModel *model = new QStandardItemModel(2,2,this); //2 Rows and 3 Columns
        model->setHorizontalHeaderItem(0, new QStandardItem(QString("ID Producto")));
        model->setHorizontalHeaderItem(1, new QStandardItem(QString("Nombre")));
        model->setHorizontalHeaderItem(2, new QStandardItem(QString("Cantidad")));



        QList<VentaDetalle*> listaDetalle=FacadeAdmin::ObtenerDetalleVenta(ven);
        qDebug()<<"init Llenado";
        qDebug()<<"size:"<<listaDetalle.size();
        for (int i = 0; i < listaDetalle.size(); ++i) {
            VentaDetalle* vendet =listaDetalle.at(i);
            qDebug()<<QString::number(vendet->GetProducto())<<" "<<QString::number(vendet->GetStock());
            model->setItem(i,0,new QStandardItem(QString::number(vendet->GetProducto())));
            model->setItem(i,2,new QStandardItem(QString::number(vendet->GetStock())));
            QList<Producto*> lprd=FacadeAdmin::BuscarProducto(vendet->GetProducto());
            if(lprd.size()==1){
                Producto * prodVent = lprd[0];
                model->setItem(i,1,new QStandardItem(prodVent->GetNombre()));
            }
        }
        ui->tvdetalle->setModel(model);
    }else{
        ui->tcodigo->setText("");
    }

}

void FormVentaDetalle::on_BBuscarProducto_clicked()
{
    QString codigo=ui->TPid->toPlainText();
    QList<Producto*> listaProd=FacadeAdmin::BuscarProducto(codigo.toInt());
    if(listaProd.size()==1){
        Producto * prod = listaProd[0];
        ui->TPNombre->setText(prod->GetNombre());
    }else{
        ui->TPid->setText("");
    }
}

void FormVentaDetalle::on_BAgregar_clicked()
{
    QString idpro=ui->TPid->toPlainText();
    QString idventa=ui->tcodigo->toPlainText();
    QString stock=ui->TVcantidad->toPlainText();
    qDebug()<<idpro<<" "<<idventa<<" "<<stock;
    FacadeAdmin::AgregarVentaDetalle(idventa.toInt(),idpro.toInt(),stock.toInt());

    QString codigo=ui->tcodigo->toPlainText();
    QList<Venta*> Lven = FacadeAdmin::BuscarVenta(codigo.toInt());
    Venta * ven;
    if(Lven.size()==1){
        ven = Lven[0];
        ui->tfecha->setText(ven->GetFechVent());
        ui->tdni->setText(QString::number(ven->GetDNIClie()));
        QList <Cliente*> cli= FacadeAdmin::BuscarCliente(ven->GetDNIClie());
        if(cli.size()==1){
            Cliente * cliente = cli[0];
            ui->tnombre->setText(cliente->GetNombre());
        }

        QStandardItemModel *model = new QStandardItemModel(2,2,this); //2 Rows and 3 Columns
        model->setHorizontalHeaderItem(0, new QStandardItem(QString("ID Producto")));
        model->setHorizontalHeaderItem(1, new QStandardItem(QString("Nombre")));
        model->setHorizontalHeaderItem(2, new QStandardItem(QString("Cantidad")));


        QList<VentaDetalle*> listaDetalle=FacadeAdmin::ObtenerDetalleVenta(ven);

        for (int i = 0; i < listaDetalle.size(); ++i) {
            VentaDetalle* vendet =listaDetalle.at(i);
            model->setItem(i,0,new QStandardItem(QString::number(vendet->GetProducto())));
            model->setItem(i,2,new QStandardItem(QString::number(vendet->GetStock())));
            QList<Producto*> lprd=FacadeAdmin::BuscarProducto(vendet->GetProducto());
            if(lprd.size()==1){
                Producto * prodVent = lprd[0];
                model->setItem(i,1,new QStandardItem(prodVent->GetNombre()));
            }

        }
        ui->tvdetalle->setModel(model);
    }else{
        ui->tcodigo->setText("");
    }
}

void FormVentaDetalle::on_BEliminar_clicked()
{
    QString idpro=ui->TPid->toPlainText();
    QString idventa=ui->tcodigo->toPlainText();
    QString stock=ui->TVcantidad->toPlainText();
    FacadeAdmin::EliminarVentaDetalle(idventa.toInt(),idpro.toInt());

    QString codigo=ui->tcodigo->toPlainText();
    QList<Venta*> Lven = FacadeAdmin::BuscarVenta(codigo.toInt());
    Venta * ven;
    if(Lven.size()==1){
        ven = Lven[0];
        ui->tfecha->setText(ven->GetFechVent());
        ui->tdni->setText(QString::number(ven->GetDNIClie()));
        QList <Cliente*> cli= FacadeAdmin::BuscarCliente(ven->GetDNIClie());
        if(cli.size()==1){
            Cliente * cliente = cli[0];
            ui->tnombre->setText(cliente->GetNombre());
        }

        QStandardItemModel *model = new QStandardItemModel(2,2,this); //2 Rows and 3 Columns
        model->setHorizontalHeaderItem(0, new QStandardItem(QString("ID Producto")));
        model->setHorizontalHeaderItem(1, new QStandardItem(QString("Nombre")));
        model->setHorizontalHeaderItem(2, new QStandardItem(QString("Cantidad")));


        QList<VentaDetalle*> listaDetalle=FacadeAdmin::ObtenerDetalleVenta(ven);

        for (int i = 0; i < listaDetalle.size(); ++i) {
            VentaDetalle* vendet =listaDetalle.at(i);
            model->setItem(i,0,new QStandardItem(QString::number(vendet->GetProducto())));
            model->setItem(i,2,new QStandardItem(QString::number(vendet->GetStock())));
            QList<Producto*> lprd=FacadeAdmin::BuscarProducto(vendet->GetProducto());
            if(lprd.size()==1){
                Producto * prodVent = lprd[0];
                model->setItem(i,1,new QStandardItem(prodVent->GetNombre()));
            }

        }
        ui->tvdetalle->setModel(model);
    }else{
        ui->tcodigo->setText("");
    }
}
