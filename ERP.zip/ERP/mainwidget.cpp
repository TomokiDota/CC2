#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "formlogin.h"
#include "formcitastodos.h"

#include "AdminCliente.h"
#include "AdminProducto.h"
#include "adminventa.h"
#include "Cliente.h"
#include "producto.h"
#include "venta.h"
#include <QtDebug>
#include <QList>


MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::on_Farmacia_clicked()
{
    FormCitasTodos * formCitasTodos=new FormCitasTodos();
    formCitasTodos->show();
}

void MainWidget::on_Administrador_clicked()
{
     FormLogin * fadmin = new FormLogin();
    fadmin->show();
}
