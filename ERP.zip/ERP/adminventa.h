#ifndef ADMINVENTA_H
#define ADMINVENTA_H
#include "Venta.h"
#include "admindata.h"
#include "AdminBase.h"
#include "ventadetalle.h"
#include <QDebug>
#include <QString>


class AdminVenta : public AdminBase
{
    public:
        static void Agregar(QString venta){
            AdminData data = AdminData::getInstance();
            data.execQuery(venta);
        }
        static QList<Venta*> BuscarPorClave(int clave){
           AdminData data = AdminData::getInstance();
           QSqlQuery query=data.execQuery("SELECT * FROM ventprod WHERE CodiVent = "+QString::number(clave)+";");
           QList<Venta*> lista;
           while (query.next()) {
               lista.append(new Venta(query.value(0).toInt(),
                                      query.value(1).toString(),
                                      query.value(2).toInt()
                                     )
                            );
           }
           return lista;
        }
        static QList<Venta*> BuscarTodos(){
            AdminData data = AdminData::getInstance();
            QSqlQuery query=data.execQuery("SELECT * FROM ventprod ;");
            QList<Venta*> lista;
            while (query.next()) {
                lista.append(new Venta(query.value(0).toInt(),
                                       query.value(1).toString(),
                                       query.value(2).toInt()
                                      )
                             );
            }
            return lista;
        }
        static void Modificar(QString venta){
            AdminData data = AdminData::getInstance();
            data.execQuery(venta);
        }
        static void Eliminar(int clave){
            AdminData data = AdminData::getInstance();
            data.execQuery("DELETE FROM ventprod WHERE CodiVent = "+QString::number(clave)+";");

        }

        static QList<VentaDetalle*> ObtenerDetalle(int idventa){
            AdminData data = AdminData::getInstance();
            QSqlQuery query=data.execQuery("SELECT * FROM detavent WHERE CodiVent ="+QString::number(idventa)+";");
            qDebug()<<"SELECT * FROM detavent WHERE CodiVent ="+QString::number(idventa)+";";
            QList<VentaDetalle*> lista;
            while (query.next()) {
                qDebug()<<query.value(0).toInt()<<" "<<query.value(1).toInt();
                lista.append(new VentaDetalle(  query.value(2).toInt(),
                                                query.value(0).toInt(),
                                                query.value(1).toInt()
                                              )
                             );
            }
            return lista;
        }

        static void AgregarProducto(int idventa, int prodClave, int stock){
            AdminData data = AdminData::getInstance();
            qDebug()<<"INSERT INTO detavent(CodiVent, CodiProd, Stock) VALUES ("+QString::number(idventa)+","+QString::number(prodClave)+","+QString::number(stock)+");";
            data.execQuery("INSERT INTO detavent(CodiVent, CodiProd, Stock) VALUES ("+QString::number(idventa)+","+QString::number(prodClave)+","+QString::number(stock)+");");
        }

        static void DeleteProducto(int idventa, int prodClave){
            AdminData data = AdminData::getInstance();
            data.execQuery("DELETE FROM detavent  WHERE  CodiVent="+QString::number(idventa)+" AND CodiProd ="+QString::number(prodClave)+";");
        }
};

#endif // ADMINVENTA_H
