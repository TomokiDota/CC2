#include "formadmin.h"
#include "ui_formadmin.h"
#include "formclientetodos.h"
#include "formproductotodos.h"
#include "formventatodos.h"

FormAdmin::FormAdmin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormAdmin)
{
    ui->setupUi(this);
}

FormAdmin::~FormAdmin()
{
    delete ui;
}

void FormAdmin::on_BCliente_clicked()
{
    FormClienteTodos* fAdminTodoCli = new FormClienteTodos();
    fAdminTodoCli->show();
}

void FormAdmin::on_BProducto_clicked()
{
    FormProductoTodos* fAdminTodoPro = new FormProductoTodos();
    fAdminTodoPro->show();
}

void FormAdmin::on_BVenta_clicked()
{
    FormVentaTodos* fAdminTodoVen = new FormVentaTodos();
    fAdminTodoVen->show();
}
