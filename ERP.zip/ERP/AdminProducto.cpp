#include "AdminProducto.h"

AdminProducto::AdminProducto()
{

}
