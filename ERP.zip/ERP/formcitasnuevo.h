#ifndef FORMCITASNUEVO_H
#define FORMCITASNUEVO_H

#include <QWidget>

namespace Ui {
class FormCitasNuevo;
}

class FormCitasNuevo : public QWidget
{
    Q_OBJECT

public:
    explicit FormCitasNuevo(QWidget *parent = 0);
    ~FormCitasNuevo();

private slots:
    void on_BNuevo_clicked();

    void on_BBuscar_clicked();

private:
    Ui::FormCitasNuevo *ui;
};

#endif // FORMCITASNUEVO_H
