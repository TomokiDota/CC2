#include "formcitastodos.h"
#include "ui_formcitastodos.h"

#include "formcitasnuevo.h"
#include "FacadeCitas.h"
#include "citas.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QStandardItem>
#include <QList>
#include <QString>

FormCitasTodos::FormCitasTodos(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormCitasTodos)
{
    ui->setupUi(this);
    QStandardItemModel *model = new QStandardItemModel(2,3,this); //2 Rows and 3 Columns
    model->setHorizontalHeaderItem(0, new QStandardItem(QString("ID Citas")));
    model->setHorizontalHeaderItem(1, new QStandardItem(QString("Consultorio")));
    model->setHorizontalHeaderItem(2, new QStandardItem(QString("DNI")));

    QList<Cita*> lista=FacadeCitas::ObtenerLista();
    //QStandardItem *firstRow = new QStandardItem(QString(lista[0]));
    //model->setItem(0,0,firstRow);

    for (int i = 0; i < lista.size(); ++i) {
        Cita* cit=lista.at(i);
        //cout << "Nombre " << cli->GetNombre() << endl;
        qDebug()<<lista.size();
        model->setItem(i,0,new QStandardItem(QString::number(cit->Getidcitas())));
        model->setItem(i,1,new QStandardItem(QString(cit->Getconsultorio())));
        model->setItem(i,2,new QStandardItem(QString::number((cit->GetDNIClie()))));

    }
    ui->Tcitas->setModel(model);
}

FormCitasTodos::~FormCitasTodos()
{
    delete ui;
}

void FormCitasTodos::on_BNuevo_clicked()
{
    FormCitasNuevo *formCitasNuevo = new FormCitasNuevo();
    formCitasNuevo->show();
}
