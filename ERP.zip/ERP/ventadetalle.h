#ifndef VENTADETALLE_H
#define VENTADETALLE_H
#include <QString>
using namespace std;

class VentaDetalle
{
    private:
        int venta;
        int producto;
        int stock;

    public:
        VentaDetalle(){

        }
        VentaDetalle(int venta, int producto, int stock){
            this->venta = venta;
            this->producto =producto;
            this->stock=stock;
        }
        virtual ~VentaDetalle(){

        }

        int GetVenta() {
            return venta;
        }
        void SetVenta(int val) {
            venta = val;
        }
        int GetProducto() {
            return producto;
        }
        void SetProducto( int val) {
            producto = val;
        }
        int GetStock() {
            return stock;
        }
        void SetStock( int val) {
            stock = val;
        }

        QString insertQuery(){
            return "INSERT INTO detavent (CodiProd, CodiVent, Stock) VALUES ("+QString::number(producto)+","+QString::number(venta)+","+QString::number(stock)+");";
        }
        QString updateQuery(){
            return "UPDATE detavent SET Stock = "+QString::number(stock)+" WHERE CodiProd= "+QString::number(producto)+" AND CodiVent = "+QString::number(venta)+";";
        }

};
#endif // VENTADETALLE_H
