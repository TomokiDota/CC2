#ifndef FACADEVENDEDOR_H
#define FACADEVENDEDOR_H

#include <QList>
#include "AdminCliente.h"
#include "AdminProducto.h"
#include "adminventa.h"
#include "admincitas.h"

class FacadeCitas{
    public:
    static QList<Cliente*> BuscarCliente(int clave){
        QList<Cliente*> lista=AdminCliente::BuscarPorClave(clave);
        return lista;
    }
    static void AgregarCitas(QString qcita){
        AdminCitas::Agregar(qcita);
    }

    static QList<Cita*> ObtenerLista(){
        QList<Cita*> data=AdminCitas::BuscarTodos();
        return data;
    }

};
#endif // FACADEVENDEDOR_H
