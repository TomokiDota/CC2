#include "AdminCliente.h"

void AdminCliente::Agregar(Cliente & cliente)

void AdminCliente::BuscarPorClave(int cliente){
    AdminData data = AdminData::getInstance();
    data.execQuery();
}

void AdminCliente::BuscarTodos(){
    AdminData data = AdminData::getInstance();
    data.execQuery();
}

void AdminCliente::Modificar(Cliente & cliente){
    AdminData data = AdminData::getInstance();
    data.execQuery();
}

void AdminCliente::Eliminar(int cliente){
    AdminData data = AdminData::getInstance();
    data.execQuery();
}
