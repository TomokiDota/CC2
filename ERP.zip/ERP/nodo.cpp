#include "Nodo.h"

template<class t_dato>
Nodo<t_dato>::Nodo(t_dato dato)
{
    this->dato = dato;
    sig = NULL;
}
