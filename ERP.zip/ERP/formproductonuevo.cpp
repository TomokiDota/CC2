#include "formproductonuevo.h"
#include "ui_formproductonuevo.h"
#include "facadeadmin.h"
#include "producto.h"
#include <QString>

FormProductoNuevo::FormProductoNuevo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormProductoNuevo)
{
    ui->setupUi(this);
}

FormProductoNuevo::~FormProductoNuevo()
{
    delete ui;
}

void FormProductoNuevo::on_BGuardar_clicked()
{
    QString Nombre=ui->TNombre->toPlainText();
    QString Precio=ui->TPrecio->toPlainText();
    QString Stock=ui->TStock->toPlainText();

    Producto * pro = new Producto(0,Nombre,Stock.toInt(),Precio.toDouble());
    FacadeAdmin::CrearProducto(pro);
    this->close();
}
