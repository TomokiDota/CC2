#include "AdminData.h"

#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QString>
#include <QMessageBox>
#include <QSqlError>

AdminData::AdminData()
{
    data = QSqlDatabase::addDatabase("QMYSQL");
    data.setHostName("localhost");
    data.setPort(3306);
    data.setDatabaseName("erp");
    data.setUserName("root");
    data.setPassword("root");
    data.open();
    qDebug() << "open Conection";
}

QSqlQuery AdminData::execQuery(QString statement){
    QSqlQuery query;
    query.exec(statement);

    return query;
}

AdminData& AdminData::getInstance(){
    static AdminData instance;
    return instance;
}

