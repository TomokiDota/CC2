#include "formclientemodificar.h"
#include "ui_formclientemodificar.h"
#include <QString>
#include "Cliente.h"
#include "facadeadmin.h"

FormClienteModificar::FormClienteModificar(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormClienteModificar)
{
    ui->setupUi(this);
}

FormClienteModificar::~FormClienteModificar()
{
    delete ui;
}

void FormClienteModificar::on_BGuardar_clicked()
{
    QString DNI=ui->TDni->toPlainText();
    QString Nombre=ui->TNombre->toPlainText();
    QString Telefono=ui->TTelefono->toPlainText();
    QString correo=ui->TCorreo->toPlainText();

    Cliente * cli = new Cliente(DNI.toInt(),Nombre,Telefono,correo);
    FacadeAdmin::ModificarCliente(cli);
    this->close();
}

void FormClienteModificar::on_BBuscar_clicked()
{
    QString dni=ui->TDni->toPlainText();
    QList<Cliente*> Lcli = FacadeAdmin::BuscarCliente(dni.toInt());
    if(Lcli.size()==1){
        Cliente * cli = Lcli[0];
        ui->TNombre->setText(cli->GetNombre());
        ui->TTelefono->setText(cli->GetTelefono());
        ui->TCorreo->setText(cli->GetCorreo());
    }else{
        ui->TDni->setText("");
    }
}
